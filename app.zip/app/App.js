import React from 'react';

// import Navigator from './routes/Drawer.js';
import Navigator from './routes/Tab.js';

const App = () => {
  return <Navigator />;
};
export default App;
