import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';

import Header from '../shared/Header';
import About from '../screens/About';

const Stack = createStackNavigator();

export default AboutStack = ({navigation}) => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {backgroundColor: 'teal', height: 60},
        headerTintColor: '#eee',
      }}>
      <Stack.Screen
        name="About"
        component={About}
        options={({route}) => ({title: 'Info'})}
        // options={{
        //   headerTitle: () => (
        //     <Header title="GameZone About" navigation={navigation} />
        //   ),
        // }}
      />
    </Stack.Navigator>
  );
};
